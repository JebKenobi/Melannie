<?php
class WPBakeryShortCode_VC_flickr extends WPBakeryShortCode {


}