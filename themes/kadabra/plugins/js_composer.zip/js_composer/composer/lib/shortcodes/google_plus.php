<?php
class WPBakeryShortCode_VC_GooglePlus extends WPBakeryShortCode {


}